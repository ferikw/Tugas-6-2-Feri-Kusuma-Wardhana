import 'package:cloud_firestore/cloud_firestore.dart';

class HomeController {
  final CollectionReference _recipeCollection =
      FirebaseFirestore.instance.collection('recipes');

  Stream<QuerySnapshot> getRecipes() {
    return _recipeCollection.snapshots();
  }

  Future<void> addRecipe(Map<String, dynamic> recipeData) {
    return _recipeCollection.add(recipeData);
  }

  Future<void> updateRecipe(String recipeId, Map<String, dynamic> newData) {
    return _recipeCollection.doc(recipeId).update(newData);
  }

  Future<void> deleteRecipe(String recipeId) {
    return _recipeCollection.doc(recipeId).delete();
  }
}
