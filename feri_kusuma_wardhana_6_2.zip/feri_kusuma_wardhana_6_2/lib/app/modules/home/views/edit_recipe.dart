import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class EditRecipe extends StatefulWidget {
  final DocumentSnapshot recipe;

  const EditRecipe({required this.recipe});

  @override
  _EditRecipeState createState() => _EditRecipeState();
}

class _EditRecipeState extends State<EditRecipe> {
  late TextEditingController _namaController;
  late TextEditingController _waktuController;
  late TextEditingController _bahanController;
  late TextEditingController _langkahController;

  @override
  void initState() {
    super.initState();
    _namaController = TextEditingController(text: widget.recipe['nama']);
    _waktuController = TextEditingController(text: widget.recipe['waktu']);
    _bahanController = TextEditingController(text: widget.recipe['bahan']);
    _langkahController = TextEditingController(text: widget.recipe['langkah']);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Resep'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller: _namaController,
                decoration: const InputDecoration(
                  labelText: 'Nama Resep',
                  prefixIcon: Icon(Icons.restaurant_menu),
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _waktuController,
                decoration: const InputDecoration(
                  labelText: 'Estimasi Waktu (menit)',
                  prefixIcon: Icon(Icons.timer),
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _bahanController,
                decoration: const InputDecoration(
                  labelText: 'Bahan',
                  prefixIcon: Icon(Icons.shopping_basket),
                ),
                maxLines: null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _langkahController,
                decoration: const InputDecoration(
                  labelText: 'Langkah-langkah',
                  prefixIcon: Icon(Icons.list),
                ),
                maxLines: null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveChanges,
                child: const Text('Simpan'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _saveChanges() {
    String newNama = _namaController.text;
    String newWaktu = _waktuController.text;
    String newBahan = _bahanController.text;
    String newLangkah = _langkahController.text;

    Map<String, dynamic> newData = {
      'nama': newNama,
      'waktu': newWaktu,
      'bahan': newBahan,
      'langkah': newLangkah,
    };

    FirebaseFirestore.instance
        .collection('recipes')
        .doc(widget.recipe.id)
        .update(newData)
        .then((_) {
      Navigator.pop(context);
    }).catchError((error) {
      print('Error update resep: $error');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Gagal menyimpan perubahan. Silakan coba lagi.'),
        ),
      );
    });
  }

  @override
  void dispose() {
    _namaController.dispose();
    _waktuController.dispose();
    _bahanController.dispose();
    _langkahController.dispose();
    super.dispose();
  }
}
