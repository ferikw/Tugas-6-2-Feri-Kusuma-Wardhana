// ignore_for_file: unused_import

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:feri_kusuma_wardhana_6_2/app/modules/home/controllers/home_controller.dart';

class AddRecipe extends StatelessWidget {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController timeController = TextEditingController();
  final TextEditingController ingredientsController = TextEditingController();
  final TextEditingController stepsController = TextEditingController();
  final HomeController _recipeController = HomeController();

  AddRecipe({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tambah Resep Baru'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Nama',
                  prefixIcon: Icon(Icons.assignment),
                ),
              ),
              TextField(
                controller: timeController,
                decoration: const InputDecoration(
                  labelText: 'Estimasi Waktu (menit)',
                  prefixIcon: Icon(Icons.timer),
                ),
              ),
              TextField(
                controller: ingredientsController,
                decoration: const InputDecoration(
                  labelText: 'Bahan',
                  prefixIcon: Icon(Icons.shopping_basket),
                ),
                maxLines: 4,
                minLines: 3,
              ),
              TextField(
                controller: stepsController,
                decoration: const InputDecoration(
                  labelText: 'Langkah-langkah',
                  prefixIcon: Icon(Icons.list),
                ),
                maxLines: 4,
                minLines: 3,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_isValidRecipe()) {
                    _recipeController.addRecipe({
                      'nama': nameController.text,
                      'waktu': timeController.text,
                      'bahan': ingredientsController.text,
                      'langkah': stepsController.text,
                    }).then((_) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Resep berhasil ditambahkan!'),
                        ),
                      );
                      Navigator.pop(context);
                    }).catchError((error) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Gagal menambahkan resep: $error'),
                        ),
                      );
                    });
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Harap isi semua'),
                      ),
                    );
                  }
                },
                child: const Text('Tambah'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  bool _isValidRecipe() {
    return nameController.text.isNotEmpty &&
        timeController.text.isNotEmpty &&
        ingredientsController.text.isNotEmpty &&
        stepsController.text.isNotEmpty;
  }
}
