// ignore_for_file: unused_import

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:feri_kusuma_wardhana_6_2/app/modules/home/controllers/home_controller.dart';
import 'package:feri_kusuma_wardhana_6_2/app/modules/home/views/add_recipe.dart';
import 'package:feri_kusuma_wardhana_6_2/app/modules/home/views/detail_recipe.dart';
import 'package:get/get.dart';

class HomeView extends StatelessWidget {
  final HomeController _recipeController = HomeController();

  HomeView({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Resep Makanan & Minuman Feri',
          style: GoogleFonts.poppins(),
        ),
      ),
      body: StreamBuilder(
        stream: _recipeController.getRecipes(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text('Tidak ada data resep.'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (context, index) {
                DocumentSnapshot<Object?> recipe = snapshot.data!.docs[index];
                return Card(
                  child: ListTile(
                    title: Text(
                      recipe['nama'],
                      style: GoogleFonts.poppins(),
                    ),
                    subtitle: Text(
                      'Estimasi Waktu: ${recipe['waktu']} menit',
                      style: GoogleFonts.poppins(),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DetailRecipe(recipe: recipe),
                        ),
                      );
                    },
                  ),
                );
              },
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddRecipe()),
          );
        },
        child: Icon(Icons.add),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
    );
  }
}
