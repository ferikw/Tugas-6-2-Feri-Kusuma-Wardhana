// ignore_for_file: unused_import

import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:feri_kusuma_wardhana_6_2/app/modules/home/views/home_view.dart';
import 'package:get/get.dart';
import '/app/routes/app_pages.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyCP3lugW28JSCz9I3aybN4C3iOfGin-sWs",
      appId: "1:422659179131:android:9137d57a3c1777b95d98de",
      messagingSenderId: "422659179131",
      projectId: "kusuma-69ba9",
    ),
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Feri',
      theme: ThemeData(
        appBarTheme: const AppBarTheme(
            backgroundColor: Colors.green,
            foregroundColor: Colors.white,
            titleTextStyle:
                TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
        primarySwatch: Colors.green,
      ),
      home: HomeView(),
    );
  }
}
