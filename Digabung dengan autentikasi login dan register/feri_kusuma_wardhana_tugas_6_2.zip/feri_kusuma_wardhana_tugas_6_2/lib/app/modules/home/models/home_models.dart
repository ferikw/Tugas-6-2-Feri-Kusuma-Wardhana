class HomeModel {
  final String nama;
  final String waktu;
  final String bahan;
  final String langkah;

  HomeModel({
    required this.nama,
    required this.waktu,
    required this.bahan,
    required this.langkah,
  });

  String get name => nama;

  String get time => waktu;

  String get ingredients => bahan;

  String get steps => langkah;

  factory HomeModel.fromMap(Map<String, dynamic> map) {
    return HomeModel(
      nama: map['nama'] ?? '',
      waktu: map['waktu'] ?? '',
      bahan: map['bahan'] ?? '',
      langkah: map['langkah'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'nama': nama,
      'waktu': waktu,
      'bahan': bahan,
      'langkah': langkah,
    };
  }
}
